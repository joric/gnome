Original model by Asci http://www.gamedev.ru/art/forum/?id=5592&page=34#m502
Texture mapping from reference image by viv http://www.gamedev.ru/art/forum/?id=5592&page=34#m507
Fixed, remapped and saved by DamOb http://www.gamedev.ru/art/forum/?id=5592&page=35#m514
Archived by Joric https://github.com/joric/gnome
