3ds Max Gnome model by DamOb: http://www.gamedev.ru/art/forum/?id=5592&page=35#m514

Uses correct model geometry uploaded by Asci: http://www.gamedev.ru/art/forum/?id=5592&page=34#m502

Texture mapping from reference image by viv: http://www.gamedev.ru/art/forum/?id=5592&page=34#m507

Archived by Joric https://github.com/joric/gnome

To export this model to FBX correctly, use Reset XForm and Flip Normals for all the objects.
